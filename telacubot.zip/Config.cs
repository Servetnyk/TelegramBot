﻿using System;

namespace telacubot
{
    public static class Config
    {
        public static readonly string token = "1853379149:AAHpRU-7neC3qw3LS3YKPZZkjdJtQpevzM4";
    }
}
